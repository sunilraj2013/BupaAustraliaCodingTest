﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestDal;
using TestModel;

namespace TestBal
{
    public class PersonBal
    {
        PersonDal dal = new PersonDal();
        public List<PersonModel> getPersonDetails()
        {
            return dal.getPersonDetails();
        }

    }
}
