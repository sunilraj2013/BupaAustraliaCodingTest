﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestModel
{
    public class PersonModel
    {
        public string Name { get; set; }
        public int Age { get; set; }
        public List<Book> Books { get; set; }
    }
    public class BookModel
    {
        public string Name { get; set; }
        public string Type { get; set; }
       // public string Title { get; set; }
    }
}
