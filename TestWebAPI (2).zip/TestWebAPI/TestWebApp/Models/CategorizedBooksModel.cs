﻿namespace TestWebApp.Models
{
    public class CategorizedBooksModel
    {
        public List<string> AdultBooks { get; set; }
        public List<string> ChildrenBooks { get; set; }
    }

}
