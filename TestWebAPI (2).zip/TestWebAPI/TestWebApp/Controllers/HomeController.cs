using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using TestModel;
using TestWebApp.Models;

namespace TestWebApp.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public async Task<IActionResult> Index()
        {
            string apiUrl = "https://localhost:7169/Books";  // Replace with actual API endpoint
            List<PersonModel> people = new List<PersonModel>();

            using (HttpClient client = new HttpClient())
            {
                var response = await client.GetAsync(apiUrl);
                if (response.IsSuccessStatusCode)
                {
                    var jsonString = await response.Content.ReadAsStringAsync();
                    people = JsonConvert.DeserializeObject<List<PersonModel>>(jsonString);
                }
            }

            // Separate books into two lists: Adults and Children
            var adultBooks = new List<string>();
            var childrenBooks = new List<string>();

            foreach (var person in people)
            {
                foreach (var book in person.Books)
                {
                    if (person.Age >= 18)
                    {
                        adultBooks.Add(book.Name);
                    }
                    else
                    {
                        childrenBooks.Add(book.Name);
                    }
                }
            }

            // Sort books alphabetically
            adultBooks.Sort();
            childrenBooks.Sort();

            // Pass the categorized books to the view
            var categorizedBooks = new CategorizedBooksModel
            {
                AdultBooks = adultBooks,
                ChildrenBooks = childrenBooks
            };

            return View(categorizedBooks);
        }
    }
}
